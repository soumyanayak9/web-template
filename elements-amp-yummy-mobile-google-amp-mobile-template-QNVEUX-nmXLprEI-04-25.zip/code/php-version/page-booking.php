<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.2.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>

<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Satisfy">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom><?php readfile( getcwd()."/styles/style.css"); ?></style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

	
<body>	
	<div class="body-bg"></div>
			
	<input type="checkbox" id="toggle-menu">
	<label class="toggle-menu-header" for="toggle-menu"><em class="l1"></em><em class="l2"></em><em class="l3"></em></label>
	
	<label class="menu-hider" for="toggle-menu"></label>

	<header class="header">
		<a href="index.php" class="header-logo"></a>
		<a href="contact.php" class="header-icon-2"><i class="fa fa-envelope-o"></i></a>
	</header>
	
	<div id="menu-sidebar" class="menu menu-sidebar">
		<div class="menu-scroll">
			<div class="menu-clear"></div><!-- Use this on pages that don't have an opened submenu-->		
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="2" class="toggle-submenu" id="toggle-1">
				<label class="menu-item" for="toggle-1"><i class="fa fa-home"></i><span>Home</span></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="index.php"><i class="fa fa-angle-right"></i>Restaurant</a>
					<a class="menu-item" href="index-sweets.php"><i class="fa fa-angle-right"></i>Bakery</a>
				</div>	
			</div>
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-2">
				<label class="menu-item" for="toggle-2"><i class="fa fa-navicon"></i><span>Menus</span></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="menu-fancy.php"><i class="fa fa-angle-right"></i>Fancy Menu</a>
					<a class="menu-item" href="menu-classic.php"><i class="fa fa-angle-right"></i>Classic Menu</a>
					<a class="menu-item" href="menu-minimal.php"><i class="fa fa-angle-right"></i><em>Minimal Menu</em></a>
					<a class="menu-item" href="menu-blackboard.php"><i class="fa fa-angle-right"></i>Blackboard Menu</a>
				</div>	
			</div>		
			<a class="menu-item" href="page-booking.php"><i class="fa fa-book"></i><strong>Booking</strong></a>	
			<a class="menu-item" href="page-locations.php"><i class="fa fa-map-marker"></i><span>Location</span></a>	
			<a class="menu-item" href="page-reviews.php"><i class="fa fa-star"></i><span>Reviews</span></a>	
			<a class="menu-item" href="page-contact.php"><i class="fa fa-envelope-o"></i><span>Contact</span></a>	
			<a class="menu-item" href="tel:+1 234 567 890"><i class="fa fa-phone"></i><span>Call Now</span></a>	
			<a class="menu-item" href="amp-features.php"><i class="fa fa-bolt"></i><span>AMP</span></a>	
		</div>			
	</div>

	
	<div class="page-content header-clear">
		<div class="page-content-scroll">
			
			<amp-img class="full-bottom" src="images/covers/5.jpg" width="600" height="400" layout="responsive"></amp-img>
			
			<div class="content">
				<h1 class="center-text uppercase ultrabold no-bottom">Book a Table</h1>
				<p class="small-text center-text half-bottom">We guarantee <i class="fa fa-heart color-red-dark"></i> every moment.</p>
				<p class="center-text">
					Looking for a beautiful night out? Make a resorevation and we'll do
					everything in our power to live up to your most highest expectations.
				</p>
			</div>
							
			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-yellow-dark fa fa-bed"></i></em>
				</div>

				<h6 class="center-text uppercase ultrabold">Breakfast</h6>
				<p class="small-text center-text half-bottom">The hours we sever early dinners</p>
				<div class="booking-hours">
					<a href="#">7:30 AM</a>
					<a href="#">8:00 AM</a>
					<a href="#">8:30 AM</a>
					<div class="clear"></div>
				</div>
				<a class="color-yellow-dark center-text uppercase ultrabold double-bottom" href="#page-form">Make a Reservation Now</a>
			</div>		
						
			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-yellow-dark fa fa-cutlery"></i></em>
				</div>

				<h6 class="center-text uppercase ultrabold">Early Dinner</h6>
				<p class="small-text center-text half-bottom">The hours we sever early dinners</p>
				<div class="booking-hours">
					<a href="#">7:30 PM</a>
					<a href="#">8:00 PM</a>
					<a href="#">8:30 PM</a>
					<div class="clear"></div>
				</div>
				<a class="color-yellow-dark center-text uppercase ultrabold double-bottom" href="#page-form">Make a Reservation Now</a>
			</div>
			
								
			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-yellow-dark fa fa-glass"></i></em>
				</div>

				<h6 class="center-text uppercase ultrabold">Late Dinner</h6>
				<p class="small-text center-text half-bottom">The hours we sever early dinners</p>
				<div class="booking-hours">
					<a href="#">10:30 PM</a>
					<a href="#">11:00 PM</a>
					<a href="#">11:30 PM</a>
					<div class="clear"></div>
				</div>
				<a class="color-yellow-dark center-text uppercase ultrabold full-bottom" href="#page-form">Make a Reservation Now</a>
			</div>
			
			<div class="decoration decoration-margins"></div>

			<amp-img class="full-bottom" id="page-form" src="images/covers/4.jpg" width="600" height="400" layout="responsive"></amp-img>
			
			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-yellow-dark fa fa-bookmark"></i></em>
				</div>
				<h1 class="center-text uppercase ultrabold no-bottom">Reservation</h1>
				<p class="small-text center-text half-bottom">Reserve your night or day.</p>
				<p class="center-text">
					Make reservations for your special event. Just give us one call and we'll arrange it for you.
				</p>
			
				<div class="decoration"></div>				
			</div>
						
			<div class="content">
				<form action-xhr="//www.enableds.com/amps/php/contact-events.php" method="POST" class="contactForm" target="_top" custom-validation-reporting="show-all-on-submit">
					<fieldset>						
						<div class="formFieldWrap">
							<label class="field-title contactNameField" for="contactNameField">Full Name:<span>(required)</span>
							</label>
							<input placeholder="John Doe" type="text" name="contactNameField" value="" class="contactField" id="contactNameField" required  /><span visible-when-invalid="valueMissing" validation-for="name5"></span>
							<span visible-when-invalid="patternMismatch" validation-for="name5">
								Please enter your first and last name separated by a space (e.g. Jane Miller)
							</span>
						</div>
						<div class="formFieldWrap">
							<label class="field-title contactEmailField" for="contactEmailField">Email: <span>(required)</span>
							</label>
							<input placeholder="mail@domain.com" type="text" name="contactEmailField" value="" class="contactField" id="contactEmailField" required /><span visible-when-invalid="valueMissing" validation-for="email5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="email5"></span>
						</div>	
						<div class="formFieldWrap">
							<label class="field-title contactPhoneField" for="contactPhoneField">Phone: <span>(required)</span>
							</label>
							<input placeholder="1 234 567 8900" type="number" name="contactPhoneField" pattern="\d*" value="" class="contactField" id="contactPhoneField"/><span visible-when-invalid="valueMissing" validation-for="phone5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="phone5"></span>
						</div>	
						<div class="formFieldWrap">
							<label class="field-title contactGuestsField" for="contactGuestsField">Party Size: <span>(required)</span>
							</label>
							<input type="number" pattern="\d*" name="contactGuestsField" placeholder="1"  min="1" max="100" class="contactField" id="contactGuestsField"/><span visible-when-invalid="valueMissing" validation-for="guests5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="guests5"></span>
						</div>		
						<div class="formFieldWrap">
							<label class="field-title contactDateField" for="contactDateField">Event Date: <span>(required)</span>
							</label>
							<input type="date" name="contactDateField" value="2017-01-01" min="2017-01-01" max="2019-12-31" class="contactField" id="contactDateField"/><span visible-when-invalid="valueMissing" validation-for="date5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="date5"></span>
						</div>
						<div class="formTextareaWrap">
							<label class="field-title contactMessageTextarea" for="contactMessageTextarea">Message: <span>(required)</span>
							</label>
							<textarea name="contactMessageTextarea" placeholder="Enter your message" class="contactTextarea" id="contactMessageTextarea"></textarea>
						</div>
						<div class="formSubmitButtonErrorsWrap contactFormButton">
							<input type="submit" class="buttonWrap button button-round bold uppercase bg-yellow-dark contactSubmitButton" value="Send Message" />
						</div>
					</fieldset>
					<div submit-success>
						<template type="amp-mustache">
							Success! Thanks {{name}} , we'll get back to you shortly. 
						</template>
					</div>
					<div submit-error>
						<template type="amp-mustache">
							Error! {{message}}
						</template>
					</div>
				</form>
			</div>
	
			
			<div class="footer">
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>
	

			
		</div>
	</div>

	
</body>
</html>