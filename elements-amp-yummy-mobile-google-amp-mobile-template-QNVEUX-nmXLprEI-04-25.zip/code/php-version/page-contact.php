<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>
<script async custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.2.js"></script>
<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
<script async custom-element="amp-iframe" src="https://cdn.ampproject.org/v0/amp-iframe-0.1.js"></script>

<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Satisfy">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom><?php readfile( getcwd()."/styles/style.css"); ?></style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

	
<body>	
	<div class="body-bg"></div>
			
	<input type="checkbox" id="toggle-menu">
	<label class="toggle-menu-header" for="toggle-menu"><em class="l1"></em><em class="l2"></em><em class="l3"></em></label>
	
	<label class="menu-hider" for="toggle-menu"></label>

	<header class="header">
		<a href="index.php" class="header-logo"></a>
		<a href="contact.php" class="header-icon-2"><i class="fa fa-envelope-o"></i></a>
	</header>
	
	<div id="menu-sidebar" class="menu menu-sidebar">
		<div class="menu-scroll">
			<div class="menu-clear"></div><!-- Use this on pages that don't have an opened submenu-->		
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="2" class="toggle-submenu" id="toggle-1">
				<label class="menu-item" for="toggle-1"><i class="fa fa-home"></i><span>Home</span></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="index.php"><i class="fa fa-angle-right"></i>Restaurant</a>
					<a class="menu-item" href="index-sweets.php"><i class="fa fa-angle-right"></i>Bakery</a>
				</div>	
			</div>
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-2">
				<label class="menu-item" for="toggle-2"><i class="fa fa-navicon"></i><span>Menus</span></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="menu-fancy.php"><i class="fa fa-angle-right"></i>Fancy Menu</a>
					<a class="menu-item" href="menu-classic.php"><i class="fa fa-angle-right"></i>Classic Menu</a>
					<a class="menu-item" href="menu-minimal.php"><i class="fa fa-angle-right"></i><em>Minimal Menu</em></a>
					<a class="menu-item" href="menu-blackboard.php"><i class="fa fa-angle-right"></i>Blackboard Menu</a>
				</div>	
			</div>		
			<a class="menu-item" href="page-booking.php"><i class="fa fa-book"></i><span>Booking</span></a>	
			<a class="menu-item" href="page-locations.php"><i class="fa fa-map-marker"></i><span>Location</span></a>	
			<a class="menu-item" href="page-reviews.php"><i class="fa fa-star"></i><span>Reviews</span></a>	
			<a class="menu-item" href="page-contact.php"><i class="fa fa-envelope-o"></i><strong>Contact</strong></a>	
			<a class="menu-item" href="tel:+1 234 567 890"><i class="fa fa-phone"></i><span>Call Now</span></a>	
			<a class="menu-item" href="amp-features.php"><i class="fa fa-bolt"></i><span>AMP</span></a>	
		</div>			
	</div>

	
	<div class="page-content header-clear">
		<div class="page-content-scroll">
			
			<amp-img class="full-bottom" src="images/covers/3.jpg" width="600" height="400" layout="responsive"></amp-img>

			<div class="content">
				<h1 class="center-text uppercase ultrabold half-bottom">CONTACT</h1>
				<p class="small-text center-text half-bottom">Let's get in touch, from events, to reservations, we can make it happen for you.</p>
				<div class="decoration"></div>				
			</div>
			
			<div class="content">
				<form action-xhr="//www.domain.com/amps/php/contact.php" method="POST" class="contactForm" target="_top" custom-validation-reporting="show-all-on-submit">
					<fieldset>
						<div class="formFieldWrap">
							<label class="field-title contactNameField" for="contactNameField">Full Name:<span>(required)</span>
							</label>
							<input type="text" placeholder="John Doe" name="contactNameField" value="" class="contactField" id="contactNameField" required  /><span visible-when-invalid="valueMissing" validation-for="name5"></span>
							<span visible-when-invalid="patternMismatch" validation-for="name5">
								Please enter your first and last name separated by a space (e.g. Jane Miller)
							</span>
						</div>
						<div class="formFieldWrap">
							<label class="field-title contactEmailField" for="contactEmailField">Email: <span>(required)</span>
							</label>
							<input type="text" placeholder="mail@domain.com" name="contactEmailField" value="" class="contactField" id="contactEmailField" required /><span visible-when-invalid="valueMissing" validation-for="email5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="email5"></span>
						</div>
						<div class="formFieldWrap">
							<label class="field-title contactPhoneField" for="contactPhoneField">Phone: <span>(required)</span>
							</label>
							<input placeholder="1 234 567 8900" type="number" name="contactPhoneField" pattern="\d*" value="" class="contactField" id="contactPhoneField"/><span visible-when-invalid="valueMissing" validation-for="phone5"></span>
							<span visible-when-invalid="typeMismatch" validation-for="phone5"></span>
						</div>	
						<div class="formTextareaWrap">
							<label class="field-title contactMessageTextarea" for="contactMessageTextarea">Message: <span>(required)</span>
							</label>
							<textarea placeholder="Enter your message here" name="contactMessageTextarea" class="contactTextarea" id="contactMessageTextarea"></textarea>
						</div>
						<div class="formSubmitButtonErrorsWrap contactFormButton">
							<input type="submit" class="buttonWrap button button-round bold uppercase bg-green-dark contactSubmitButton" value="Send Message" />
						</div>
					</fieldset>
					<div submit-success>
						<template type="amp-mustache">
							Success! Thanks {{name}} , we'll get back to you shortly. 
						</template>
					</div>
					<div submit-error>
						<template type="amp-mustache">
							Error! {{message}}
						</template>
					</div>
				</form>
				<div class="decoration"></div>
			</div>

			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-black fa fa-phone"></i></em>
				</div>
				<h1 class="center-text uppercase ultrabold half-bottom">CALL US</h1>
				<p class="small-text center-text half-bottom">Let's get in touch, from events, to reservations, we can make it happen for you.</p>
				<div class="decoration"></div>				
			</div>
			
			<div class="content">
				<h5>Contact Information</h5>
				<a href="#" class="contact-icon"><i class="fa fa-phone"></i>+123 456 7890</a>
				<a href="#" class="contact-icon"><i class="fa fa-comments"></i>+123 456 7890</a>
				<a href="#" class="contact-icon"><i class="fa fa-fax"></i>+123 456 7890</a>
				<a href="#" class="contact-icon"><i class="fa fa-envelope"></i>mail@domain.com</a>
				<a href="#" class="contact-icon"><i class="fa fa-facebook"></i>enabled.labs</a>
				<a href="#" class="contact-icon full-bottom"><i class="fa fa-twitter"></i>@iEnabled</a>
			</div>	
			
			<div class="decoration decoration-margins"></div>

			<div class="content">
				<div class="decoration-fancy">
					<strong></strong><span></span><em><i class="color-black fa fa-map-marker"></i></em>
				</div>
				<h1 class="center-text uppercase ultrabold half-bottom">WE'RE HERE</h1>
				<p class="small-text center-text half-bottom">Let's get in touch, from events, to reservations, we can make it happen for you.</p>
				<div class="decoration"></div>				
			</div>
						
			<div class="content">
				<h5>Postal Information</h5>
				<p>
					PO Box 22161 Street Collins East<br>
					PO Box 16122 Collins Street West<br>
					Victoria 8007 Australia<br>
				</p>
			</div>	
			<div class="decoration decoration-margins"></div>
			
			<div class="content">
				<h5>Envato Headquarters</h5>
				<p>
					121 King Street, Melbourne<br>
					Victoria 3000 Australia
				</p>
			</div>
			
			<amp-iframe class="full-bottom" width="600" height="300" layout="responsive" sandbox="allow-scripts allow-same-origin allow-popups" frameborder="0" src="https://maps.google.com/?ie=UTF8&ll=47.595131,-122.330414&spn=0.006186,0.016512&t=h&z=17&output=embed"></amp-iframe>
			<div class="decoration decoration-margins"></div>
			
			<div class="footer">
				<div class="decoration decoration-margins"></div>
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="decoration decoration-margins"></div>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>

			
		</div>
	</div>

	
</body>
</html>