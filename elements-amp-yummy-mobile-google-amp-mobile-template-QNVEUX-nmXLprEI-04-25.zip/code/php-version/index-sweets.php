<!doctype html>
<html ⚡>
<head>
<meta charset="utf-8">
<script async src="https://cdn.ampproject.org/v0.js"></script>

<!--AMP HTML files require a canonical link pointing to the regular HTML. If no HTML version exists, it should point to itself.-->
<link rel="canonical" href="index.html">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Satisfy">
<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1,maximum-scale=1,user-scalable=no"><meta name="apple-mobile-web-app-capable" content="yes"/><meta name="apple-mobile-web-app-status-bar-style" content="black">
<style amp-custom><?php readfile( getcwd()."/styles/style.css"); ?></style>
<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
</head>

	
<body>	
	<div class="body-bg"></div>
			
	<input type="checkbox" id="toggle-menu">
	<label class="toggle-menu-header" for="toggle-menu"><em class="l1"></em><em class="l2"></em><em class="l3"></em></label>
	
	<label class="menu-hider" for="toggle-menu"></label>

	<header class="header">
		<a href="index.php" class="header-logo"></a>
		<a href="contact.php" class="header-icon-2"><i class="fa fa-envelope-o"></i></a>
	</header>
	
	<div id="menu-sidebar" class="menu menu-sidebar">
		<div class="menu-scroll">
			<div class="menu-clear"></div><!-- Use this on pages that don't have an opened submenu-->		
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="2" class="toggle-submenu" id="toggle-1">
				<label class="menu-item" for="toggle-1"><i class="fa fa-home active-icon"></i><strong>Home</strong></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="index.php"><i class="fa fa-angle-right"></i>Restaurant</a>
					<a class="menu-item" href="index-sweets.php"><i class="fa fa-angle-right"></i><em>Bakery</em></a>
				</div>	
			</div>
			<div class="submenu-item">
				<input type="checkbox" data-submenu-items="4" class="toggle-submenu" id="toggle-2">
				<label class="menu-item" for="toggle-2"><i class="fa fa-navicon"></i><span>Menus</span></label>
				<div class="submenu-wrapper">
					<a class="menu-item" href="menu-fancy.php"><i class="fa fa-angle-right"></i>Fancy Menu</a>
					<a class="menu-item" href="menu-classic.php"><i class="fa fa-angle-right"></i>Classic Menu</a>
					<a class="menu-item" href="menu-minimal.php"><i class="fa fa-angle-right"></i>Minimal Menu</a>
					<a class="menu-item" href="menu-blackboard.php"><i class="fa fa-angle-right"></i>Blackboard Menu</a>
				</div>	
			</div>		
			<a class="menu-item" href="page-booking.php"><i class="fa fa-book"></i><span>Booking</span></a>	
			<a class="menu-item" href="page-locations.php"><i class="fa fa-map-marker"></i><span>Location</span></a>	
			<a class="menu-item" href="page-reviews.php"><i class="fa fa-star"></i><span>Reviews</span></a>	
			<a class="menu-item" href="page-contact.php"><i class="fa fa-envelope-o"></i><span>Contact</span></a>	
			<a class="menu-item" href="tel:+1 234 567 890"><i class="fa fa-phone"></i><span>Call Now</span></a>	
			<a class="menu-item" href="amp-features.php"><i class="fa fa-bolt"></i><span>AMP</span></a>	
		</div>			
	</div>

	
	<div class="page-content">
		<div class="page-content-scroll">
			
			<div class="cover-class cover-bg-2">
				<div class="cover-content">
					<a href="#" class="cover-logo"></a>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
						Maecenas blandit faucibus mattis. Donec pharetra odio convalli
					</p>
				</div>
				<a href="#" class="cover-cta">PLACE YOUR ORDER</a>
				<div class="cover-overlay"></div>
			</div>
			<div class="cover-boxes">
				<a href="#"><i class="color-pink-light fa fa-cutlery"></i><em>Menu</em></a>
				<a href="#"><i class="color-pink-light fa fa-book"></i><em>Booking</em></a>
				<a href="#"><i class="color-pink-light fa fa-map-marker"></i><em>Locations</em></a>
				<a href="#"><i class="color-pink-light fa fa-facebook-square"></i><em>Facebook</em></a>
				<a href="#"><i class="color-pink-light fa fa-twitter-square"></i><em>Twitter</em></a>
				<a href="#"><i class="color-pink-light fa fa-instagram"></i><em>Instagram</em></a>
				<div class="clear"></div>
			</div>
			
			<div class="content full-top">
				<div class="decoration"></div>
				<h1 class="center-text half-bottom heading-cursive heading-large color-pink-dark">Sweet Tooth</h1>
				<p class="center-text">
					Your Restaurant deserves a fast loading, high ranking site. 
					AMP will load your page instantly.
				</p>
			</div>
			
			<div class="decoration decoration-margins"></div>

			<div class="content">
				<div class="home-bar home-bar-3-icons">
					<a href="#"><i class="fa fa-coffee color-blue-light"></i>Brunch</a>
					<a href="#"><i class="fa fa-birthday-cake color-pink-dark"></i>Cakes</a>
					<a href="#"><i class="fa fa-trophy color-yellow-dark"></i>Others</a>
					<div class="clear"></div>
				</div>
			</div>
			
			<div class="decoration decoration-margins"></div>
			
			
			<div class="content">
				<h1 class="center-text heading-cursive color-pink-dark heading-large half-bottom">Our Cakes</h1>
				<p class="center-text boxed-text">
					Freshly backed on the spot in an old school wood furnace to offer it that amazing extra taste.
				</p>
				<div class="home-thumbnails home-2-thumbs">
					<a href="#">
						<amp-img src="images/food/sweets/sweet-2.png" width="200" height="200" layout="responsive"></amp-img>
						<u>$9.99</u>
						<strong class="color-black">Strawbery Cake</strong>
						<em>Mozzarela / Tomatoes</em>
						<span class="color-red-dark">$19.99</span>
					</a>
					<a href="#">
						<amp-img src="images/food/sweets/sweet-1.png" width="200" height="200" layout="responsive"></amp-img>
						<u>$9.99</u>
						<strong class="color-black">Tiramisu Cake</strong>
						<em>Mozzarela / Olives / Cheese</em>
						<span class="color-red-dark">$29.99</span>
					</a>
					<a href="#">
						<amp-img src="images/food/sweets/sweet-3.png" width="200" height="200" layout="responsive"></amp-img>
						<u>$9.99</u>
						<strong class="color-black">Waffel & Sauce</strong>
						<em>Sauce / Mozzarela / Mushrooms</em>
						<span class="color-red-dark">$39.99</span>
					</a>
					<a href="#">
						<amp-img src="images/food/sweets/sweet-2.png" width="200" height="200" layout="responsive"></amp-img>
						<u>$9.99</u>
						<strong class="color-black">Cherry Cake</strong>
						<em>Sauce / Mozzarela / 4 Cheeses</em>
						<span class="color-red-dark">$29.99</span>

					</a>
					<div class="clear"></div>
				</div>				
			</div>			
			
			<div class="decoration decoration-margins"></div>
			
			<a href="#" class="content home-delivery">
				<i class="fa fa-car color-pink-dark"></i>
				<h1 class="ultrabold heading-cursive color-pink-dark">24/7 Delivery</h1>
				<em>Enjoy from the comfort of your home</em>
			</a>
			
			<div class="decoration decoration-margins"></div>
			
			<div class="content">
				<div class="home-bar home-bar-4-icons home-bar-large-icons">
					<a href="#"><i class="fa fa-phone-square color-green-dark"></i>Call</a>
					<a href="#"><i class="fa fa-envelope-square color-blue-dark"></i>Mail</a>
					<a href="#"><i class="fa fa-facebook-square facebook-color"></i>Like</a>
					<a href="#"><i class="fa fa-twitter-square twitter-color"></i>Follow</a>
					<div class="clear"></div>
				</div>
			</div>
			
			<div class="decoration decoration-margins"></div>
			
			<div class="content">
				<h1 class="center-text heading-cursive heading-large color-pink-dark half-bottom">Event Catering</h1>
				<p class="center-text boxed-text no-bottom">
					The most important meal of the day, served with coffee on the house!
				</p>
				<div class="home-thumbnails home-1-thumbs">
					<a href="#">
						<amp-img src="images/food/sweets/sweet-4.png" width="200" height="200" layout="responsive"></amp-img>
						<strong class="color-pink-dark heading-cursive color-pink-dark">Cakes & Cookies</strong>
						<em>Mozzarela, Tomatoes, Orange Juice</em>
						<span class="color-red-dark">$19.99</span>
					</a>
				</div>
				<div class="home-thumbnails home-2-thumbs">
					<a href="#">
						<amp-img src="images/food/sweets/sweet-2.png" width="200" height="200" layout="responsive"></amp-img>
						<strong class="color-black">Baked</strong>
						<em>Mozzarela, Olives,  Cheese</em>
						<span class="color-red-dark">$29.99</span>
					</a>
					<a href="#">
						<amp-img src="images/food/sweets/sweet-1.png" width="200" height="200" layout="responsive"></amp-img>
						<strong class="color-black">Sugar Free</strong>
						<em>Sauce, Mozzarela, Mushrooms</em>
						<span class="color-red-dark">$39.99</span>
					</a>
					<div class="clear"></div>
				</div>				
			</div>
						
			<div class="decoration decoration-margins"></div>
			
			<div class="cover-boxes full-bottom">
				<a href="#"><i class="fa color-pink-dark fa-cutlery"></i><em>Menu</em></a>
				<a href="#"><i class="fa color-pink-dark fa-book"></i><em>Booking</em></a>
				<a href="#"><i class="fa color-pink-dark fa-map-marker"></i><em>Locations</em></a>
				<div class="clear"></div>
			</div>
			
			<div class="decoration decoration-margins"></div>
			
			<div class="content">
				<i class="fa fa-trophy heading-icon center-text full-bottom color-yellow-dark"></i>
				<h3 class="center-text half-bottom heading-cursive color-pink-dark heading-large">Professional Cook</h3>
				<p class="boxed-text center-text">
					Cooked with raw passion by skilled chefs that love seeing your eyes
					glow with each bite.
				</p>			
				<a href="#" class="center-text uppercase bold color-yellow-dark full-bottom">INTERVIEW WITH OUR CHEF</a>
			</div>
			
			<div class="decoration decoration-margins"></div>
					
			<div class="content-fullscreen">
				<i class="fa fa-heart heading-icon center-text full-bottom color-red-dark"></i>
				<h3 class="center-text half-bottom heading-cursive color-pink-dark heading-large">Customers Love Us</h3>
				<p class="boxed-text center-text">
					We love to see our customers leave with their taste buds delighted and they say
					amazing things.
				</p>			
				<a href="#" class="center-text uppercase bold color-red-dark full-bottom">Read Testimonials</a>
			</div>	
			
			<div class="decoration decoration-margins"></div>
			
			<div class="content">
				<div class="home-bar home-bar-2-icons home-bar-large-icons">
					<a href="#"><i class="fa fa-phone-square color-green-dark"></i>24/7 Delivery</a>
					<a href="#"><i class="fa fa-calendar color-blue-dark"></i>Reserve Event</a>
					<div class="clear"></div>
				</div>
			</div>
			
			<div class="decoration decoration-margins"></div>

			<div class="footer">
				<a href="#" class="footer-logo"></a>
				<p class="boxed-text center-text">
					We aim to simplify your life by creating a beautiful and simple product that's feature rich and easy to use!
				</p>
				<div class="footer-socials">
					<a href="https://www.facebook.com/enabled.labs/" class="facebook-bg"><i class="fa fa-facebook"></i></a>
					
					<a href="https://twitter.com/iEnabled" class="twitter-bg"><i class="fa fa-twitter"></i></a>
					<a href="tel:+1-234-567-8901" class="phone-bg"><i class="fa fa-phone"></i></a>
					<a href="mailto:name@domain.com" class="mail-bg"><i class="fa fa-envelope"></i></a>
					<a href="#" class="bg-magenta-dark"><i class="fa fa-angle-up"></i></a>
					<div class="clear"></div>
				</div>
				<div class="decoration decoration-margins"></div>
				<p class="center-text">Copyright Enabled. All rights reserved.</p>
			</div>
			
		</div>
	</div>

	
</body>
</html>